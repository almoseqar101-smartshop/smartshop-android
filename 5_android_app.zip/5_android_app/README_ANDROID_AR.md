# تطبيق الأندرويد (Android App / APK) — نظام المدير الذكي

هذا المجلد يحتوي على مشروع تطبيق الأندرويد الكامل مبنياً بـ **Capacitor** (الواجهة مدمجة بالكامل داخل التطبيق + وضع الطوارئ 24 ساعة عند انقطاع الإنترنت)، ويتصل مباشرة بقاعدة بيانات السيرفر الأونلاين (**PythonAnywhere** أو أي سيرفر REST API).

---

## أولاً: طريقة ضبط أو تغيير رابط قاعدة البيانات (PythonAnywhere)

يمكنك تغيير رابط السيرفر بطريقتين:

### الطريقة 1: من ملف الإعدادات قبل استخراج الـ APK
1. افتح الملف:
   `dist/app-config.json`
2. اكتب رابط موقعك على PythonAnywhere في السطر الأول:
   ```json
   {
     "apiBaseUrl": "https://YOUR_USERNAME.pythonanywhere.com",
     "windowsAppUrl": "",
     "androidAppUrl": ""
   }
   ```
3. احفظ الملف ثم نفّذ `npx cap sync android` قبل بناء الـ APK.

### الطريقة 2: من داخل التطبيق على الموبايل (في أي وقت بدون إعادة بناء APK!)
1. عند فتح التطبيق على الأندرويد، اضغط على زر **«تغيير رابط السيرفر»** في أعلى شاشة الدخول.
2. اكتب رابط سيرفرك (مثال: `https://hamdy.pythonanywhere.com`).
3. اضغط **«حفظ واختبار»** — وسيُحفظ فوراً في ذاكرة الهاتف.

---

## ثانياً: استخراج ملف الأندرويد (`.apk`)

### الطريقة الأسهل (بضغطة زر على GitHub — مجاناً بدون Android Studio):
1. ارفع محتويات مجلد `5_android_app` إلى مستودع (Repository) على حسابك في GitHub (مع التأكد من وجود مجلد `.github/workflows/build-android.yml` المرفق).
2. ادخل على تبويب **Actions** في GitHub واضغط **Run workflow**.
3. خلال 3 دقائق ستجد ملف الـ `.apk` جاهزاً للتحميل من قسم **Artifacts**.

### الطريقة المحلية (عبر Android Studio):
1. تأكد من تثبيت Node.js 18+ و Android Studio.
2. شغّل الملف `prepare-android-windows.bat` (أو نفّذ في الطرفية):
   ```bash
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
3. *(لعمل مسح الباركود بالكاميرا داخل التطبيق)* تأكد في `android/app/src/main/AndroidManifest.xml` من وجود السطرين:
   ```xml
   <uses-permission android:name="android.permission.INTERNET" />
   <uses-permission android:name="android.permission.CAMERA" />
   ```
4. من قائمة Android Studio اختر: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

---

## ثالثاً: وضع رابط التحميل في صفحة السيستم للمشتركين
بعد استخراج ملف `.apk` ورفعه على استضافتك أو Google Drive / GitHub Releases:
1. افتح النظام من المتصفح واضغط **«دخول المشرف العام»**.
2. افتح قسم **«روابط تحميل تطبيق الكمبيوتر والأندرويد»**.
3. الصق رابط ملف الأندرويد واضغط **«حفظ الروابط»** — وسيظهر زر التحميل فوراً لكل العملاء في شاشة الدخول!
