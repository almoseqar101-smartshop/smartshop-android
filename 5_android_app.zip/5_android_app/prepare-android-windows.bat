@echo off
echo === تجهيز مشروع الأندرويد للنظام (المدير الذكي) ===
call npm install
if not exist "android" (
  call npx cap add android
)
call npx cap sync android
echo.
echo تم تجهيز مجلد android بنجاح!
echo لفتح المشروع وبناء APK اضغط متابعة لفتحه في Android Studio...
call npx cap open android
pause
